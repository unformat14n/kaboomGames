function loader(){
  loadFont('magicia', "assets/sprites/magic-font.png", 10, 11, {chars: 'ABCDEFGHIJKLMNOPQRSTUVWXYZ.!?,'});
  loadSprite('magic 8 ball', 'assets/sprites/magic-eight-ball.png')
}
export default loader;